#include "vst2.hpp"
#include "engine.hpp"
#include "parameters.hpp"
#include "presets.hpp"
#include "rate.hpp"
#include <atomic>
#include <memory>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <new>
namespace {
constexpr uint32_t ID=0x4d67474c;
struct Chunk {uint32_t magic=0x474c5354,version=3,count=PARAMS,program=0;float values[PARAMS];char name[24]{};};
float clean(float x){return std::isfinite(x)?std::clamp(x,-1.f,1.f):0.f;}
int32_t pcm(float x){return int32_t(std::clamp(double(clean(x))*2147483648.,-2147483648.,2147483647.));}
struct Plugin {
 AEffect fx{};audioMasterCallback host;std::atomic<float> params[PARAMS];std::unique_ptr<Engine> engine;
 double rate=44100;int latency=104;Sinc down,up;History input,wet;int64_t nextNative=0;int fill=0;int32_t blockIn[32]{},blockOut[32]{};
 Chunk chunk{};int currentProgram=0;char program[24]="Clean Start";std::atomic<bool> hostBypass{false};bool ready=false;float mixCurrent=.4f;
 Plugin(audioMasterCallback h):host(h){for(int i=0;i<PARAMS;++i)params[i].store(presetValues[0][i]);configure(44100);}
 void configure(double sr){if(!std::isfinite(sr)||sr<8000||sr>192000)return;rate=sr;latency=int(std::ceil(Sinc::H+(Sinc::H+32)*sr/32000.))+2;fx.initialDelay=latency;down.configure(std::min(1.,32000./sr)*.94);up.configure(std::min(1.,sr/32000.)*.94);input.clear();wet.clear();nextNative=0;fill=0;}
 void activate(){ready=false;engine=std::make_unique<Engine>();input.clear();wet.clear();nextNative=0;fill=0;ready=true;}
 void snapshot(float* v){for(int i=0;i<PARAMS;++i)v[i]=params[i].load(std::memory_order_relaxed);}
 static int option(float v,int count){return std::clamp(int(std::lround(v*(count-1))),0,count-1);}
 void controls(const float* v){uint8_t p[14]{};for(int i=0;i<6;++i)p[i+1]=uint8_t(std::lround(v[i]*255));
  // Firmware's control link uses physical-knob order. Some boolean fields are active-low.
  p[7]=1|(1<<2)|((option(v[P_noise],3)+1)<<4)|64;
  p[8]=(v[P_classic]<.5f?64:0)|(v[P_miso]<.5f?32:0)|(v[P_spread]<.5f?16:0)|8|(v[P_drop]<.5f?4:0)|(v[P_snag]<.5f?2:0)|(v[P_hum]<.5f?1:0);
  // Aux stays idle: this insert exposes sound controls, not pedal performance switches.
  p[9]=127;p[10]=uint8_t(std::lround(v[P_hiss]*255));p[11]=uint8_t(std::lround(v[P_mechanical]*255));p[12]=uint8_t(std::lround(v[P_crinkle]*255));p[13]=option(v[P_gain],3);engine->packet(p);
 }
 void process(float** ins,float** outs,int n){if(n<=0||!outs)return;float v[PARAMS];snapshot(v);bool bypass=hostBypass.load();
  if(!ready){for(int i=0;i<n;++i){float l=ins&&ins[0]?clean(ins[0][i]):0,r=ins&&ins[1]?clean(ins[1][i]):l;if(outs[0])outs[0][i]=l;if(outs[1])outs[1][i]=r;}return;}

  for(int i=0;i<n;++i){Stereo x{ins&&ins[0]?clean(ins[0][i]):0,ins&&ins[1]?clean(ins[1][i]):0};input.push(x);
   while(double(nextNative)*rate/32000.+Sinc::H<=input.last){Stereo z=down.sample(input,double(nextNative)*rate/32000.);++nextNative;blockIn[fill*2]=pcm(z.l);blockIn[fill*2+1]=pcm(z.r);if(++fill==16){
    controls(v);engine->process16(blockIn,blockOut);for(int k=0;k<16;++k)wet.push({blockOut[2*k]*(1.f/2147483648.f),blockOut[2*k+1]*(1.f/2147483648.f)});fill=0;}}
   Stereo y{},dry=input.get(input.last-latency);
   if(input.last>=latency)y=up.sample(wet,(input.last-latency)*32000./rate);
   // Host-native linear blend; keep the firmware's parallel dry path disabled.
   mixCurrent+=std::clamp(v[P_mix]-mixCurrent,-float(1./(.01*rate)),float(1./(.01*rate)));
   y.l=dry.l*(1-mixCurrent)+y.l*mixCurrent;y.r=dry.r*(1-mixCurrent)+y.r*mixCurrent;
   if(bypass)y=dry;
   if(outs[0])outs[0][i]=std::isfinite(y.l)?y.l:0;
   if(outs[1])outs[1][i]=std::isfinite(y.r)?y.r:0;
  }
 }
};
Plugin* get(AEffect*e){return static_cast<Plugin*>(e->object);}
void put(char*dst,const char*s,size_t n){if(dst&&s&&n){std::strncpy(dst,s,n-1);dst[n-1]=0;}}
void set(AEffect*e,int32_t i,float v){if(i>=0&&i<PARAMS&&std::isfinite(v))get(e)->params[i].store(std::clamp(v,0.f,1.f),std::memory_order_relaxed);}
float value(AEffect*e,int32_t i){return i>=0&&i<PARAMS?get(e)->params[i].load(std::memory_order_relaxed):0;}
void process(AEffect*e,float**in,float**out,int32_t n){get(e)->process(in,out,n);}
const char* opts(int i,int k){static const char* noise[]={"None","Mild","Heavy"},*gain[]={"Line","Inst","High"};if(i==P_noise)return noise[k];if(i==P_gain)return gain[k];return k?"On":"Off";}
intptr_t dispatch(AEffect*e,int32_t op,int32_t i,intptr_t val,void*ptr,float opt){auto*p=get(e);switch(op){
 case 0:try{p->activate();return 1;}catch(...){return 0;}
 case 1:delete p;return 1;
 case 2:if(val>=0&&val<PROGRAMS){p->currentProgram=val;put(p->program,presetNames[val],24);for(int k=0;k<PARAMS;++k)set(e,k,presetValues[val][k]);return 1;}return 0;
 case 3:return p->currentProgram;
 case 4:put(p->program,(const char*)ptr,sizeof(p->program));return 0;
 case 5:put((char*)ptr,p->program,24);return 1;
 case 6:put((char*)ptr,"",8);return 0;
 case 7:if(i>=0&&i<PARAMS){char s[16];float v=value(e,i);if(steps[i])put(s,opts(i,Plugin::option(v,steps[i])),sizeof(s));else if(i==P_mix)std::snprintf(s,sizeof(s),"%.0f%% wet",v*100);else std::snprintf(s,sizeof(s),"%.1f",v*100);put((char*)ptr,s,8);}return 0;
 case 8:if(i>=0&&i<PARAMS)put((char*)ptr,names[i],8);return 0;
 case 10:p->configure(opt);return 0;
 case 11:return 0;
 case 12:if(val&&!p->ready){try{p->activate();}catch(...){return 0;}}return 1;
 case 23:if(!ptr)return 0;p->snapshot(p->chunk.values);p->chunk.program=p->currentProgram;put(p->chunk.name,p->program,24);*(void**)ptr=&p->chunk;return sizeof(Chunk);
 case 24:if(ptr&&val==sizeof(Chunk)){Chunk c;std::memcpy(&c,ptr,sizeof(c));if(c.magic!=0x474c5354||c.version!=3||c.count!=PARAMS||c.program>=PROGRAMS||!std::memchr(c.name,0,24))return 0;for(float v:c.values)if(!std::isfinite(v)||v<0||v>1)return 0;for(int k=0;k<PARAMS;++k)set(e,k,c.values[k]);p->currentProgram=c.program;put(p->program,c.name,24);return 1;}return 0;
 case 26:return i>=0&&i<PARAMS;
 case 29:if(i>=0&&i<PROGRAMS){put((char*)ptr,presetNames[i],24);return 1;}return 0;
 case 35:return 1;
 case 44:p->hostBypass.store(val!=0);return 1;
 case 45:put((char*)ptr,"Magic Cliff Loss",32);return 1;
 case 47:put((char*)ptr,"MagicStino",64);return 1;
 case 48:put((char*)ptr,"Magic Cliff Loss",64);return 1;
 case 49:return 100;
 case 51:return 0;
 case 56:return 2400;
 default:return 0;
 }}
}
extern "C" __attribute__((visibility("default"))) AEffect* VSTPluginMain(audioMasterCallback host){try{auto*p=new Plugin(host);auto&e=p->fx;e.magic=0x56737450;e.dispatcher=dispatch;e.setParameter=set;e.getParameter=value;e.process=e.processReplacing=process;e.numPrograms=PROGRAMS;e.numParams=PARAMS;e.numInputs=e.numOutputs=2;e.flags=(1<<4)|(1<<5);e.object=p;e.uniqueID=ID;e.version=100;e.initialDelay=p->latency;e.ioRatio=1;return &e;}catch(...){return nullptr;}}
