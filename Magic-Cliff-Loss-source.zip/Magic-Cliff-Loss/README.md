# Magic Cliff Loss

Experimental stereo insert effect for ARMv7 Akai Force / MPC Gen1 custom-plugin setups. It adapts the digital processing in a locally supplied Generation Loss MKII 1.1.0 firmware image, with a grey cliff panel with large black-and-white controls and outlined VHS-style labels, 18 automatable sound controls, Q-Link maps, and ten factory presets including **Rhodes Drive** and **Noisy Rhodes**.

![Magic Cliff Loss panel](docs/panel-0.png)

**Preview status:** digital-core comparisons and ARM-host tests pass. The supplied skin targets OS 3.x; actual Force/MPC operation, CPU headroom, and analog pedal equivalence are not yet validated. This is an effect, not an instrument, and not a desktop x86 VST or a standard stock-firmware installer.

## Effect workflow

Insert Magic Cliff Loss on an audio track, choose a preset, then shape Wow, Flutter, Saturate/Gen, Model/LP and Failure/HP. Adjust Volume for the source. Mix starts at 40% wet and blends the original and processed signals; Noise selects the noise amount. Routing and detail settings live on Character and Setup.

Tape Stop, Aux triggers, and pedal-style stop/release controls are intentionally omitted. The original Aux input stays idle. Use the host's normal insert bypass. This is a sound-processing insert, not a transport or record player.

[Control and Q-Link map](docs/CONTROLS.md).

## Presets

Clean Start · Soft Focus · Warm VHS · Worn Cassette · Rhodes Drive · Noisy Rhodes · Wide Memories · Cliff Edge · Dusty Loop · Classic Haze.

[Preset descriptions](docs/PRESETS.md). Factory programs are embedded in the VST, and ten native `.xpl` effect presets are installed in the plugin’s `Presets/` folder. Their complete state, program names and parameter values are round-trip tested against the actual ARM plugin. All presets start at 40% wet. On-device preset-browser discovery remains to be confirmed. Presets are starting points, not level-matched or physical-pedal comparison recordings.

## Build locally

The public repository excludes the proprietary firmware and any binary containing it. Supply your own exact `genLoss1.1.0.bin` (SHA256 `f9bfb4bfb28c551c1390a6ff1fc5c26873f5e3381ace65b7b363bd22e86cba67`). The preparation tool rejects other files.

On a Linux system with Python 3, Make, and an ARM hard-float C++17 cross compiler:

```sh
make firmware FIRMWARE=/path/to/genLoss1.1.0.bin
make
make test-build
```

Output: `build/genloss.so`. Tests require ARM Linux or QEMU with an ARM sysroot. The generated `src/engine_blob.hpp` is local-only and ignored by Git. Do not upload it or the compiled plugin without establishing redistribution rights.

For the skin, use the MIT-licensed [mpc-vst-plugins toolkit](https://github.com/sd88me/mpc-vst-plugins), revision `97a2effca4114dd00f738b018e2f0d1d3ccb2d7f`, with its Python/Pillow/Playwright Chromium art dependencies:

```sh
python3 tools/parameters.py
python3 tools/presets.py
python3 tools/panel.py
SHADOW_TITLE_FONT="$PWD/vst/art/TapeLabels.ttf" python3 /path/to/mpc-vst-plugins/tools/gen_vst.py vst/vst.json
python3 tools/export_native_presets.py
```

Use the toolkit's `release.py` with the compiled `.so`, generated skin folder and pluginlist entry. This produces the custom-host install/uninstall package. Stock Akai firmware does not expose this third-party installation workflow; follow your established compatible custom-plugin setup.

## Findings and validation

[Reusable firmware findings](docs/FIRMWARE-NOTES.txt) distinguish verified observations from assumptions, including the three ARM floating-point instruction substitutions, 651 relocations, control packet, sample-rate adapter, and the touch-event limitation found during an earlier Aux experiment. [Validation](docs/VALIDATION.txt) records the tests and outstanding hardware checks.

The public adaptation code is MIT licensed; third-party tooling retains its own notice. Firmware is separate and is not relicensed. This is an independent project, not affiliated with Chase Bliss or Akai. Generation Loss identifies the source firmware; Rhodes describes the intended electric-piano use of two presets.
