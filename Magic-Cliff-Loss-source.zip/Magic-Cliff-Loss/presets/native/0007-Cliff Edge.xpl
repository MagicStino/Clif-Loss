<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-28-00-00"/>
  <PLUGIN name="Magic Cliff Loss" descriptiveName="Magic Cliff Loss" format="VST" category="Effect" manufacturer="MagicStino"
          version="1.0" file="%payload-path%/MagicStino - VST - Magic Cliff Loss/genloss.so" uid="4d67474c" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Cliff Edge</preset>
  <state>272.CMlaKA....fQBMDZ....AzzYGwD....Y....A...............................................................................................................................................................................vQ0TLcz.....R....b....P35QwO....+vdT37SOJbsOlYl49XlYl7SyLyrO....+................................nYlY3C...vOyLyL+....7yPrklYlARQjcVY...................</state>
</pluginstate>
