#include "../src/engine.hpp"
#include <cstdio>
#include <fstream>
#include <string>
int main(){try{for(int flags:{0,32,64,96}){Engine e;uint8_t p[14]={0,64,128,0,64,64,0,0x2a,(uint8_t)flags,0,0,0,0,0};e.packet(p);std::ifstream in("build/research/input-"+std::to_string(flags)+".pcm",std::ios::binary);std::ofstream out("build/research/native-"+std::to_string(flags)+".pcm",std::ios::binary);if(!in||!out)return 2;int32_t x[32],y[32];while(in.read((char*)x,128)){e.process16(x,y);out.write((char*)y,128);}std::printf("mode %d complete\n",flags);}}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;} }
