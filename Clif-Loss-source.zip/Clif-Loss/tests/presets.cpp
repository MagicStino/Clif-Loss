#include "../src/vst2.hpp"
#include "../src/parameters.hpp"
#include "../src/presets.hpp"
#include <dlfcn.h>
#include <fstream>
#include <vector>
#include <string>
#include <iterator>
#include <cassert>
#include <cstring>
#include <cstdio>
intptr_t host(AEffect*,int32_t op,int32_t,intptr_t,void*,float){return op==1?2400:0;}
int main(int argc,char**argv){assert(argc==3);void*lib=dlopen(argv[1],RTLD_NOW);assert(lib);auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");auto*e=make(host);assert(e&&e->numPrograms==PROGRAMS);assert(e->getParameter(e,P_mix)==.4f);
for(int p=0;p<PROGRAMS;++p){char name[24]{};assert(e->dispatcher(e,29,p,0,name,0));assert(!strcmp(name,presetNames[p]));assert(e->dispatcher(e,2,0,p,nullptr,0));assert(e->dispatcher(e,3,0,0,nullptr,0)==p);for(int i=0;i<PARAMS;++i)assert(e->getParameter(e,i)==presetValues[p][i]);
 std::ifstream f(std::string(argv[2])+"/"+std::to_string(p)+".chunk",std::ios::binary);assert(f);std::vector<char>chunk((std::istreambuf_iterator<char>(f)),{});for(int i=0;i<PARAMS;++i)e->setParameter(e,i,0);assert(e->dispatcher(e,24,0,chunk.size(),chunk.data(),0));for(int i=0;i<PARAMS;++i)assert(e->getParameter(e,i)==presetValues[p][i]);e->dispatcher(e,5,0,0,name,0);assert(!strcmp(name,presetNames[p]));
 void* saved=nullptr;int size=e->dispatcher(e,23,0,0,&saved,0);assert(size==int(chunk.size())&&!memcmp(saved,chunk.data(),size));printf("Native XPL and factory recall: %s\n",name);
}
e->setParameter(e,P_mix,.73f);char custom[]="My Rhodes";e->dispatcher(e,4,0,0,custom,0);void*ptr=nullptr;int size=e->dispatcher(e,23,0,0,&ptr,0);std::vector<char>saved((char*)ptr,(char*)ptr+size);auto*fresh=make(host);assert(fresh->dispatcher(fresh,24,0,size,saved.data(),0));assert(fresh->getParameter(fresh,P_mix)==.73f);char name[24]{};fresh->dispatcher(fresh,5,0,0,name,0);assert(!strcmp(name,custom));fresh->dispatcher(fresh,1,0,0,nullptr,0);e->dispatcher(e,1,0,0,nullptr,0);dlclose(lib);puts("PASS: native preset chunks, all controls, 40% Mix defaults, edited state and custom name recall in a fresh instance");}
