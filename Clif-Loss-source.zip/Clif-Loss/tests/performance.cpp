#include "../src/plugin.cpp"
#include <cassert>
#include <vector>
intptr_t testHost(AEffect*,int32_t op,int32_t,intptr_t,void*,float){return op==1?2400:0;}
int main(){Plugin p(testHost);p.activate();p.configure(32000);float l[160],r[160],a[160],b[160];float*in[]={l,r},*out[]={a,b};int t=0;auto run=[&](int count){double energy=0;for(int k=0;k<count;++k){for(int j=0;j<160;++j,++t){l[j]=.15f*std::sin(t*.043f)+.08f*std::sin(t*.067f);r[j]=.18f*std::sin(t*.057f);}p.process(in,out,160);for(int j=0;j<160;++j){assert(std::isfinite(a[j])&&std::isfinite(b[j]));assert(std::abs(a[j])<3&&std::abs(b[j])<3);energy+=a[j]*a[j]+b[j]*b[j];}}return energy;};
for(int k=0;k<PROGRAMS;++k){for(int i=0;i<PARAMS;++i)p.params[i]=presetValues[k][i];double e=run(100);assert(e>0);printf("preset %s: finite stereo output, energy %.5f\n",presetNames[k],e);}puts("PASS: all ten factory presets");}
