#include "../src/plugin.cpp"
#include <cassert>
#include <cstdio>
intptr_t testHost(AEffect*,int32_t op,int32_t,intptr_t,void*,float){return op==1?2400:0;}
int main(){Plugin dry(testHost),wet(testHost),blend(testHost);for(auto*p:{&dry,&wet,&blend}){p->activate();p->configure(32000);}dry.params[P_mix]=0;wet.params[P_mix]=1;blend.params[P_mix]=.4f;
float l[128],r[128],dl[128],dr[128],wl[128],wr[128],bl[128],br[128];float*in[]={l,r},*od[]={dl,dr},*ow[]={wl,wr},*ob[]={bl,br};for(int k=0;k<50;++k){for(int i=0;i<128;++i){l[i]=.2f*std::sin((k*128+i)*.02f);r[i]=.1f*std::cos((k*128+i)*.04f);}dry.process(in,od,128);wet.process(in,ow,128);blend.process(in,ob,128);if(k>3)for(int i=0;i<128;++i){int t=k*128+i-dry.latency;assert(std::abs(dl[i]-.2f*std::sin(t*.02f))<1e-6f);assert(std::abs(dr[i]-.1f*std::cos(t*.04f))<1e-6f);assert(std::abs(bl[i]-(.6f*dl[i]+.4f*wl[i]))<1e-6f);assert(std::abs(br[i]-(.6f*dr[i]+.4f*wr[i]))<1e-6f);}}
puts("PASS: Mix dry endpoint and 40/60 blend on both channels; no duplicated firmware dry signal");}
