#include "../src/vst2.hpp"
#include "../src/parameters.hpp"
#include "../src/presets.hpp"
#include <dlfcn.h>
#include <cassert>
#include <vector>
#include <cstdio>
#include <cstring>
#include <array>
static bool loading=false;static int updates=0;static std::array<int,PARAMS> seen{};static std::array<float,PARAMS> shown{};
bool active(int i){return i!=P_drop&&i!=P_snag&&i!=P_gain;}
intptr_t host(AEffect* e,int32_t op,int32_t i,intptr_t,void*,float v){
 if(op==1)return 2400;
 if(op==0){assert(!loading);assert(i>=0&&i<PARAMS&&active(i));++seen[i];shown[i]=v;assert(v==e->getParameter(e,i));e->setParameter(e,i,v);}
 if(op==42){assert(!loading);++updates;}
 return 0;
}
void clear(){seen.fill(0);updates=0;}
void block(AEffect* e){float a[16]{},b[16]{},c[16]{},d[16]{};float*in[]={a,b},*out[]={c,d};e->processReplacing(e,in,out,16);}
void check(AEffect*e){assert(updates==1);for(int i=0;i<PARAMS;++i){assert(seen[i]==int(active(i)));if(active(i))assert(shown[i]==e->getParameter(e,i));}clear();block(e);assert(updates==0);for(auto n:seen)assert(n==0);}
int main(int argc,char**argv){assert(argc==2);void*lib=dlopen(argv[1],RTLD_NOW);assert(lib);auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");auto*e=make(host);assert(e);for(int p=0;p<PROGRAMS;++p){clear();loading=true;assert(e->dispatcher(e,2,0,p,nullptr,0));loading=false;assert(updates==0);for(auto n:seen)assert(n==0);block(e);check(e);
 void*ptr=nullptr;int n=e->dispatcher(e,23,0,0,&ptr,0);std::vector<char>saved((char*)ptr,(char*)ptr+n);for(int i=0;i<PARAMS;++i)e->setParameter(e,i,0);loading=true;assert(e->dispatcher(e,24,0,n,saved.data(),0));loading=false;assert(updates==0);block(e);check(e);
 saved[0]^=1;assert(!e->dispatcher(e,24,0,n,saved.data(),0));block(e);assert(updates==0);
}
// Coalesce rapid picks and reflect the latest manual edit, without an echo loop.
e->dispatcher(e,2,0,1,nullptr,0);e->dispatcher(e,2,0,2,nullptr,0);e->setParameter(e,P_mix,.73f);block(e);assert(shown[P_mix]==.73f);check(e);
for(int i=0;i<PARAMS;++i)e->setParameter(e,i,.2f);block(e);assert(updates==0);for(auto n:seen)assert(n==0);
e->dispatcher(e,1,0,0,nullptr,0);dlclose(lib);puts("PASS: 15 preset programs/chunks refresh 15 visible controls once, deferred, echo safe; invalid state and host edits do not refresh; rapid picks coalesce.");}
