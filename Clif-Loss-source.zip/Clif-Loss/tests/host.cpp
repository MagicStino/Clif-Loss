#include "../src/vst2.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include <limits>
#include <cstdint>
intptr_t host(AEffect*,int32_t op,int32_t,intptr_t,void*,float){return op==1?2400:0;}
int main(int argc,char**argv){assert(argc==2);void*lib=dlopen(argv[1],RTLD_NOW);if(!lib){puts(dlerror());return 1;}auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");assert(make);auto*a=make(host),*b=make(host);assert(a&&b&&a!=b);assert(a->numInputs==2&&a->numOutputs==2&&a->numParams==18&&!(a->flags&(1<<8)));assert(a->dispatcher(a,0,0,0,nullptr,0)==1);assert(b->dispatcher(b,0,0,0,nullptr,0)==1);
for(int k=0;k<18;++k){assert(a->dispatcher(a,26,k,0,nullptr,0));float v=(k+1)/19.f;a->setParameter(a,k,v);assert(a->getParameter(a,k)==v);assert(a->getParameter(a,k)!=b->getParameter(b,k));}
void* cp=nullptr;int n=a->dispatcher(a,23,0,0,&cp,0);assert(n>0&&cp);std::vector<unsigned char>chunk((unsigned char*)cp,(unsigned char*)cp+n);a->dispatcher(a,2,0,0,nullptr,0);assert(a->dispatcher(a,24,0,n,chunk.data(),0));for(int k=0;k<18;++k)assert(a->getParameter(a,k)==(k+1)/19.f);chunk[0]^=1;assert(!a->dispatcher(a,24,0,n,chunk.data(),0));assert(!a->dispatcher(a,24,0,n-1,cp,0));float keep=a->getParameter(a,0);a->setParameter(a,0,std::numeric_limits<float>::quiet_NaN());assert(a->getParameter(a,0)==keep);
float l[1024],r[1024],ol[1024],orr[1024];float*in[]={l,r},*out[]={ol,orr};uint32_t rnd=42;double energy=0;
for(float sr:{32000.f,44100.f,48000.f,96000.f}){a->dispatcher(a,2,0,0,nullptr,0);a->dispatcher(a,10,0,0,nullptr,sr);assert(a->initialDelay>0);for(int block=0;block<180;++block){int sizes[]={1,7,16,31,64,128,257,1024};int frames=sizes[block%8];for(int j=0;j<frames;++j){rnd^=rnd<<13;rnd^=rnd>>17;rnd^=rnd<<5;l[j]=int32_t(rnd)*(0.125f/2147483648.f);r[j]=.08f*std::sin((block*1000+j)*.08f);}if(block<132){int k=block%18;a->setParameter(a,k,(block/18)%2?1:0);}a->processReplacing(a,in,out,frames);for(int j=0;j<frames;++j){assert(std::isfinite(ol[j])&&std::isfinite(orr[j]));assert(std::abs(ol[j])<4&&std::abs(orr[j])<4);energy+=ol[j]*ol[j]+orr[j]*orr[j];}}printf("rate %.0f variable-block and control sweep passed; latency %d\n",sr,a->initialDelay);}
assert(energy>0);a->dispatcher(a,10,0,0,nullptr,44100);a->dispatcher(a,44,0,1,nullptr,0);int latency=a->initialDelay;std::vector<float>input;for(int block=0;block<10;++block){for(int j=0;j<128;++j){l[j]=r[j]=(block*128+j)/2000.f;input.push_back(l[j]);}a->processReplacing(a,in,out,128);for(int j=0;j<128;++j){int index=block*128+j-latency;float expect=index>=0?input[index]:0;assert(ol[j]==expect&&orr[j]==expect);}}
a->dispatcher(a,1,0,0,nullptr,0);b->dispatcher(b,1,0,0,nullptr,0);dlclose(lib);puts("PASS: effect category, 18 automation controls, independent instances, valid/invalid chunks, NaN rejection, four sample rates, variable blocks, finite audio, latency-aligned bypass");}
