<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-28-00-00"/>
  <PLUGIN name="Clif Loss" descriptiveName="Clif Loss" format="VST" category="Effect" manufacturer="MagicStino"
          version="1.0" file="%payload-path%/MagicStino - VST - Clif Loss/genloss.so" uid="4d67474c" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Soft Focus</preset>
  <state>272.CMlaKA....fQBMDZ....AzzYGwD....Y....A...............................................................................................................................................................................vQ0TLcz.....R....D....fBWOZO....+nv0i1SyLyTOZlYF9.....PyLyrO.........................................7C...vO....+....7yTuYFcfXzaiU2b...................</state>
</pluginstate>
