#pragma once
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <sys/mman.h>
#include <vector>
#include "engine_blob.hpp"
struct ScopedFP {unsigned saved;ScopedFP(){asm volatile("vmrs %0, fpscr":"=r"(saved));unsigned zero=0;asm volatile("vmsr fpscr, %0"::"r"(zero));}~ScopedFP(){asm volatile("vmsr fpscr, %0"::"r"(saved));}};
class Engine {
 uint8_t *code=nullptr,*ram=nullptr,*delay=nullptr;
 static constexpr size_t CS=0x20000,RS=0x80000,DS=0x40000;
 static uint8_t* alloc(size_t n){auto p=mmap(nullptr,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(p==MAP_FAILED)throw std::runtime_error("memory allocation failed");return (uint8_t*)p;}
 uint32_t relocate(uint32_t v){if(v>=0x08000000&&v<0x08020000)return (uintptr_t)code+v-0x08000000;if(v>=0x24000000&&v<0x24080000)return (uintptr_t)ram+v-0x24000000;if(v>=0x30000000&&v<0x30040000)return (uintptr_t)delay+v-0x30000000;throw std::runtime_error("invalid relocation");}
 void call0(uint32_t off){reinterpret_cast<void(*)()>((uintptr_t)code+off+1)();}
 public:
 Engine(){ScopedFP fp;try{code=alloc(CS);ram=alloc(RS);delay=alloc(DS);std::memcpy(code,engine_blob,sizeof(engine_blob));for(uint32_t loc:engine_relocs){uint32_t v;std::memcpy(&v,code+loc,4);v=relocate(v);std::memcpy(code+loc,&v,4);}std::memcpy(ram,code+0x10658,0x5278);__builtin___clear_cache((char*)code,(char*)code+CS);if(mprotect(code,CS,PROT_READ|PROT_EXEC))throw std::runtime_error("executable memory failed");call0(0x5d0);reinterpret_cast<void(*)(float)>((uintptr_t)code+0x6c9)(60.f);call0(0x848);}catch(...){cleanup();throw;}}
 ~Engine(){cleanup();}
 Engine(const Engine&)=delete;Engine& operator=(const Engine&)=delete;
 void cleanup(){if(code)munmap(code,CS);if(ram)munmap(ram,RS);if(delay)munmap(delay,DS);code=ram=delay=nullptr;}
 float readFloat(unsigned off)const{float v;std::memcpy(&v,ram+off,4);return v;}
 void packet(const uint8_t* p){std::memcpy(ram+0xa3d0,p,14);}
 void process16(const int32_t* in,int32_t* out){ScopedFP fp;std::memcpy(ram+0xa0d4,in,128);reinterpret_cast<void(*)(int)>((uintptr_t)code+0x5db9)(0);call0(0x2520);std::memcpy(out,ram+0x9ee8,128);}
};
