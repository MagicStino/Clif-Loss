#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <algorithm>
struct Stereo {float l=0,r=0;};
struct History {
 static constexpr int N=4096;std::array<Stereo,N> data{};int64_t last=-1;
 void push(Stereo x){data[(++last)&(N-1)]=x;}
 Stereo get(int64_t i)const {return i<0||i>last||i<=last-N?Stereo{}:data[i&(N-1)];}
 void clear(){last=-1;data.fill({});}
};
struct Sinc {
 static constexpr int H=24,P=1024,T=H*2;std::array<float,P*T> table{};
 void configure(double cutoff){
  constexpr double pi=3.14159265358979323846;
  for(int p=0;p<P;++p){double frac=double(p)/P,sum=0;
   for(int j=0;j<T;++j){double x=(j-H+1)-frac;double y=x*cutoff;
    double sinc=std::abs(y)<1e-12?1:std::sin(pi*y)/(pi*y);
    double window=std::abs(x)>=H?0:0.42+0.5*std::cos(pi*x/H)+0.08*std::cos(2*pi*x/H);
    double v=cutoff*sinc*window;table[p*T+j]=float(v);sum+=v;}
   for(int j=0;j<T;++j)table[p*T+j]=float(table[p*T+j]/sum);
  }
 }
 Stereo sample(const History& h,double t)const{
  int64_t k=int64_t(std::floor(t));int phase=std::clamp(int((t-k)*P),0,P-1);Stereo y{};
  const float* c=table.data()+phase*T;
  for(int j=0;j<T;++j){Stereo x=h.get(k+j-H+1);y.l+=x.l*c[j];y.r+=x.r*c[j];}return y;
 }
};
