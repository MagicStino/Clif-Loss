#pragma once
static constexpr int PARAMS=18;
static const char* names[]={"Wow","Volume","Model / LP","Flutter","Saturate / Gen","Failure / HP","Mix","Noise","Classic","Mono to Stereo","Spread","Drop Bypass","Snag Bypass","Hum Bypass","Hiss Level","Mechanical Noise","Crinkle / Pop","Input Gain"};
static constexpr float defaults[]={0.2f,0.5f,0.25f,0.15f,0.25f,0.1f,0.4f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.5f,0.5f,0.5f,0.5f};
static constexpr int steps[]={0,0,0,0,0,0,0,3,2,2,2,2,2,2,0,0,0,3};
enum Parameter {P_wow,P_volume,P_model,P_flutter,P_saturate,P_failure,P_mix,P_noise,P_classic,P_miso,P_spread,P_drop,P_snag,P_hum,P_hiss,P_mechanical,P_crinkle,P_gain};
