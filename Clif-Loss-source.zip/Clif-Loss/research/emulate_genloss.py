from pathlib import Path
import struct,json,time
from unicorn import *
from unicorn.arm_const import *
from firmware_input import B
class Firmware:
 def __init__(self, model=UC_CPU_ARM_MAX):
  u=self.u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
  u.ctl_set_cpu_model(model)
  for addr,size in [(0x08000000,0x20000),(0x20000000,0x20000),(0x24000000,0x80000),(0x30000000,0x40000),(0xe000e000,0x2000)]: u.mem_map(addr,size)
  u.mem_write(0x08000000,B);u.mem_write(0x24000000,B[0x10658:0x158d0])
  self.gpio_calls=[]
  def gpio(u,address,size,unused):
   self.gpio_calls.append(tuple(u.reg_read(r) for r in [UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2]))
   u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
  u.hook_add(UC_HOOK_CODE,gpio,begin=0x08009e20,end=0x08009e20)
  u.reg_write(UC_ARM_REG_C1_C0_2,0xf00000)
  u.reg_write(UC_ARM_REG_FPEXC,0x40000000)
  u.mem_write(0xe000ed88,struct.pack('<I',0xf00000))
 def call(self,addr,r0=0,s0=0):
  u=self.u;u.reg_write(UC_ARM_REG_SP,0x2001fff0);u.reg_write(UC_ARM_REG_LR,0x0801fff1);u.reg_write(UC_ARM_REG_R0,r0);u.reg_write(UC_ARM_REG_S0,struct.unpack('<I',struct.pack('<f',s0))[0])
  try:u.emu_start(addr|1,0x0801fff0,count=2000000)
  except UcError as e: raise RuntimeError(f'{e} PC={u.reg_read(UC_ARM_REG_PC):08x}')
  if u.reg_read(UC_ARM_REG_PC)!=0x0801fff0:raise RuntimeError('instruction limit')
  return u.reg_read(UC_ARM_REG_R0)
if __name__=='__main__':
 f=Firmware()
 for addr,s0 in [(0x80005d0,0),(0x80006c8,60),(0x8000848,0),(0x8005db8,0)]:
  t=time.monotonic();f.call(addr,s0=s0);print(hex(addr),'returned',round(time.monotonic()-t,4))
 print('out',struct.unpack('<32i',f.u.mem_read(0x24009ee8,128)))
