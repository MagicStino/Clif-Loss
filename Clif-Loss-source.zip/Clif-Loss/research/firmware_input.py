from pathlib import Path
import os,hashlib
path=os.environ.get('GENLOSS_FIRMWARE')
if not path: raise SystemExit('Set GENLOSS_FIRMWARE to your local genLoss1.1.0.bin')
B=Path(path).read_bytes()
if hashlib.sha256(B).hexdigest()!='f9bfb4bfb28c551c1390a6ff1fc5c26873f5e3381ace65b7b363bd22e86cba67':raise SystemExit('Firmware hash mismatch')
Path('build/research').mkdir(parents=True,exist_ok=True)
