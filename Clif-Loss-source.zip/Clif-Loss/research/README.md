# Reproducing the bounded core comparison

Run from the repository root. Install `unicorn` and `capstone` in a separate Python environment, then:

```sh
export GENLOSS_FIRMWARE=/path/to/genLoss1.1.0.bin
python3 tools/prepare_firmware.py "$GENLOSS_FIRMWARE"
python3 research/verify_native.py
```

This compares original firmware (Unicorn MAX) with relocated/patched firmware (Cortex-A15), writing private input/output fixtures under ignored `build/research`. Optionally use `map_code.py` to reproduce the reachable-code map. The known relocation set includes the initialized-data pointer at file offset `0x1586c` in addition to that map.

Compile `tests/core_compare.cpp` for ARM hard-float and run under QEMU or ARM Linux from the repository root. Compare the resulting `native-*.pcm` byte-for-byte against `original-*.pcm`. Fixtures, disassembly, original firmware, and patched binaries must remain local.

This confirms four configurations, not all parameter values, analog circuitry, host UI, or hardware CPU performance. Hash checks and instruction limits guard against accidentally using a different image. Never reuse these addresses for another pedal.
