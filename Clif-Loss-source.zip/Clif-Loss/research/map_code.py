from pathlib import Path
from capstone import *
from capstone.arm import *
import struct,json,collections
from firmware_input import B;base=0x8000000
md=Cs(CS_ARCH_ARM,CS_MODE_THUMB);md.detail=True
roots=[0x80005d0,0x80006c8,0x8000848,0x8005db8,0x8002520]
queue=roots[:];seen={};tables={};issues=[];calls=collections.defaultdict(set);relocs=set();floats=set()
while queue:
 start=queue.pop()
 if start in seen or start==0x8009e20:continue
 prev=[]
 for i in md.disasm(B[start-base:0x10658],start):
  if i.address in seen:break
  seen[i.address]=i
  if i.mnemonic.startswith(('ldr','vldr')) and len(i.operands)>1 and i.operands[1].type==ARM_OP_MEM and i.operands[1].mem.base==ARM_REG_PC:
   loc=((i.address+4)&~3)+i.operands[1].mem.disp
   val=struct.unpack_from('<I',B,loc-base)[0]
   if i.mnemonic.startswith('v'):floats.add(loc)
   elif any(a<=val<a+n for a,n in [(base,len(B)),(0x24000000,0x80000),(0x30000000,0x40000)]):relocs.add(loc)
  if i.mnemonic in ('bl','blx'):
   if i.operands[0].type==ARM_OP_IMM:
    target=i.operands[0].imm;queue.append(target);calls[target].add(i.address)
   else:issues.append((hex(i.address),i.mnemonic,i.op_str))
  elif i.group(CS_GRP_JUMP):
   targets=[o.imm for o in i.operands if o.type==ARM_OP_IMM]
   queue.extend(targets)
   if i.mnemonic=='bx' and i.op_str=='lr':break
   if i.mnemonic in ('b','b.w') and i.cc==ARM_CC_AL:break
  elif i.mnemonic.startswith('pop') and ARM_REG_PC in [o.reg for o in i.operands]:
   if i.cc==ARM_CC_AL:break
  elif i.mnemonic.startswith('ldr') and i.operands[0].reg==ARM_REG_PC:
   if prev and prev[-1].mnemonic=='adr':
    table=((prev[-1].address+4)&~3)+prev[-1].operands[1].imm
    targets=[]
    for loc in range(table,table+256,4):
     val=struct.unpack_from('<I',B,loc-base)[0]
     if val&1 and base<=val<base+0x10658:targets.append(val&~1);relocs.add(loc)
     else:break
    tables[table]=targets;queue.extend(targets)
   else:issues.append((hex(i.address),i.mnemonic,i.op_str))
   break
  prev.append(i)
  if len(prev)>4:prev.pop(0)
Path('build/research/reachable.asm').write_text('\n'.join(f'{a:08x}: {i.mnemonic:12} {i.op_str}' for a,i in sorted(seen.items())))
res={'roots':[hex(x) for x in roots],'instructions':len(seen),'calls':{hex(k):[hex(v) for v in sorted(s)] for k,s in sorted(calls.items())},'tables':{hex(k):[hex(v) for v in s] for k,s in tables.items()},'relocations':[hex(x) for x in sorted(relocs)],'issues':issues,'float_pointer_conflicts':[hex(x) for x in relocs&floats]}
Path('build/research/code-map.json').write_text(json.dumps(res,indent=2))
print(json.dumps({k:v for k,v in res.items() if k!='relocations'},indent=2))
