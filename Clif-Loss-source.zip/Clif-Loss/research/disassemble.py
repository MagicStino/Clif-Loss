from pathlib import Path
from capstone import *
import struct,sys
from firmware_input import B as b; md=Cs(CS_ARCH_ARM,CS_MODE_THUMB|CS_MODE_MCLASS)
start=int(sys.argv[1],16); end=int(sys.argv[2],16)
for i in md.disasm(b[start:end],0x8000000+start):
 s=f'{i.address:08x}: {i.mnemonic:10} {i.op_str}'
 if '[pc,' in i.op_str:
  import re
  m=re.search(r'\[pc, #(0x[\da-f]+|\d+)\]',i.op_str)
  if m:
   off=((i.address+4)&~3)+int(m[1],0)-0x8000000
   if off+4<=len(b): s+=f' ; [{off+0x8000000:08x}] = {struct.unpack_from("<I",b,off)[0]:08x}'
 print(s)
