from pathlib import Path
import struct,json,time,math,random
from emulate_genloss import Firmware
from unicorn import *
from unicorn.arm_const import *
class Relocated(Firmware):
 def __init__(self):
  super().__init__(UC_CPU_ARM_CORTEX_A15);u=self.u
  raw=bytearray(Path('build/engine.bin').read_bytes())
  self.bases=[(0x08000000,0x10000000,0x20000),(0x24000000,0x25000000,0x80000),(0x30000000,0x31000000,0x40000)]
  for a,new,n in self.bases:u.mem_map(new,n)
  for loc in json.loads(Path('tools/relocations.json').read_text()):
   v=struct.unpack_from('<I',raw,loc)[0]
   for old,new,n in self.bases:
    if old<=v<old+n:struct.pack_into('<I',raw,loc,v-old+new);break
   else:raise AssertionError(hex(v))
  u.mem_write(0x10000000,bytes(raw));u.mem_write(0x25000000,bytes(raw[0x10658:0x158d0]))
  # Remove old regions to prove no old pointer can silently remain in use.
  for a,new,n in self.bases:u.mem_unmap(a,n)
 def call(self,addr,r0=0,s0=0):
  u=self.u;u.reg_write(UC_ARM_REG_SP,0x2001fff0);u.reg_write(UC_ARM_REG_LR,0x1001fff1);u.reg_write(UC_ARM_REG_R0,r0);u.reg_write(UC_ARM_REG_S0,struct.unpack('<I',struct.pack('<f',s0))[0])
  try:u.emu_start(addr-0x8000000+0x10000001,0x1001fff0,count=2000000)
  except UcError as e:raise RuntimeError(f'{e} PC={u.reg_read(UC_ARM_REG_PC):08x}')
  assert u.reg_read(UC_ARM_REG_PC)==0x1001fff0
if __name__=='__main__':
 results=[];rng=random.Random(42)
 for flags in [0,32,64,96]:
  a=Firmware();b=Relocated()
  for addr,s in [(0x80005d0,0),(0x80006c8,60),(0x8000848,0)]:
   a.call(addr,s0=s);b.call(addr,s0=s)
  packet=bytes([0,64,128,0,64,64,0,0x2a,flags,0,0,0,0,0])
  a.u.mem_write(0x2400a3d0,packet);b.u.mem_write(0x2500a3d0,packet)
  mismatch=0;peak=0;inputs=bytearray();outputs=bytearray()
  for j in range(512):
   x=struct.pack('<32i',*[rng.randrange(-(1<<28),1<<28) for _ in range(32)])
   inputs.extend(x)
   for f,base in [(a,0x24000000),(b,0x25000000)]:
    f.u.mem_write(base+0xa0d4,x);f.call(0x8005db8);f.call(0x8002520)
   ao=bytes(a.u.mem_read(0x24009ee8,128));bo=bytes(b.u.mem_read(0x25009ee8,128));assert ao==bo,(flags,j)
   outputs.extend(ao)
   peak=max(peak,max(map(abs,struct.unpack('<32i',ao))))
  Path(f'build/research/input-{flags}.pcm').write_bytes(inputs)
  Path(f'build/research/original-{flags}.pcm').write_bytes(outputs)
  r={'flags':flags,'frames':8192,'output':'bit-identical','peak':peak};print(r);results.append(r)
 Path('build/research/relocation-verification.json').write_text(json.dumps(results,indent=2))
