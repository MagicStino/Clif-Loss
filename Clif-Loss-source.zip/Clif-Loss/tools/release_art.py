"""Compose exact brand typography over the existing cliff asset; no new AI image."""
from pathlib import Path
import base64,asyncio
from playwright.async_api import async_playwright
r=Path(__file__).resolve().parent.parent
art=r/'artwork';art.mkdir(exist_ok=True)
image=base64.b64encode((r/'vst/art/cliff-original.png').read_bytes()).decode()
font=base64.b64encode((r/'vst/art/TapeLabels.ttf').read_bytes()).decode()
def svg(w,h,tile=False):
 if tile:
  labels='<text x="15" y="61" font-size="27" letter-spacing="-1">CLIF LOSS</text><text x="16" y="91" font-size="9" letter-spacing="1" style="fill:white;stroke:none">STEREO TAPE EFFECT</text>'
 else:
  labels='<text x="64" y="83" font-size="22" letter-spacing="5">MAGICSTINO</text><text x="60" y="240" font-size="62" letter-spacing="9"></text><text x="55" y="355" font-size="112" letter-spacing="-3">CLIF LOSS</text><path d="M64 395H880" stroke="white" stroke-width="2"/><text x="64" y="446" font-size="25" letter-spacing="4">STEREO TAPE EFFECT</text><text x="64" y="654" font-size="21" letter-spacing="2">FORCE / MPC</text>'
 if w==640:
  labels=labels.replace('<text x="64" y="83" font-size="22" letter-spacing="5">MAGICSTINO</text>','')
  labels=labels.replace('font-size="25" letter-spacing="4"','font-size="25" letter-spacing="4" style="fill:white;stroke:none"').replace('font-size="21" letter-spacing="2"','font-size="21" letter-spacing="2" style="fill:white;stroke:none"')
 vw,vh=(270,110) if tile else (1280,720)
 return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {vw} {vh}"><defs><style>@font-face{{font-family:Tape;src:url(data:font/ttf;base64,{font})}}text{{font-family:Tape,monospace;fill:#080808;stroke:#fff;stroke-width:{2.6 if tile else 6};paint-order:stroke fill;stroke-linejoin:round}}</style><linearGradient id="shade"><stop stop-color="#ddd" stop-opacity=".30"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient></defs><image href="data:image/png;base64,{image}" width="{vw}" height="{vh}" preserveAspectRatio="xMidYMid slice"/><rect width="{vw}" height="{vh}" fill="url(#shade)"/>{labels}</svg>'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,args=['--no-sandbox'])
  for name,w,h,tile in [('release-cover',1280,720,False),('catalog-thumbnail',640,360,False),('browser-tile',270,110,True)]:
   page=await browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   await page.set_content('<html><body style="margin:0">'+svg(w,h,tile)+'</body></html>')
   await page.evaluate('document.fonts.ready')
   await page.screenshot(path=str(art/(name+'.png')));await page.close()
  await browser.close()
asyncio.run(main())
print('Rendered release cover 1280x720, catalog thumbnail 640x360, browser tile 270x110')
