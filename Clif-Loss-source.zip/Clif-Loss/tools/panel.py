from pathlib import Path
import json,base64
root=Path(__file__).resolve().parent.parent
img=base64.b64encode((root/'vst/art/cliff-original.png').read_bytes()).decode()
font=base64.b64encode((root/'vst/art/TapeLabels.ttf').read_bytes()).decode()
def artwork(name,labels):
 text=''.join(f'<text x="{x}" y="{y-92}" text-anchor="middle" class="label">{label}</text>' for x,y,label in labels)
 svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="628" viewBox="0 0 1280 628"><defs><style>@font-face{{font-family:VHS;src:url(data:font/ttf;base64,{font})}} .label{{font-family:VHS,monospace;font-size:24px;fill:#080808;stroke:#fff;stroke-width:2.4px;paint-order:stroke fill;stroke-linejoin:round;letter-spacing:0.3px}}</style><linearGradient id="wash" x2="0" y2="1"><stop stop-color="#dedfe0" stop-opacity=".88"/><stop offset=".68" stop-color="#d7d8d9" stop-opacity=".66"/><stop offset="1" stop-color="#aeb0b3" stop-opacity=".08"/></linearGradient></defs><image href="data:image/png;base64,{img}" width="1280" height="628" preserveAspectRatio="xMidYMid slice"/><rect width="1280" height="628" fill="url(#wash)"/><path d="M55 94H1225" stroke="#787d82"/><text x="60" y="60" class="label" style="font-size:37px;letter-spacing:3px">CLIF LOSS</text>{text}</svg>'''
 (root/f'vst/art/{name}.svg').write_text(svg)
cfg=dict(name='Clif Loss',vendor='MagicStino',uid='MgGL',version=100,so='genloss.so',params='params.json',layout='layout.conf',effect=True,cc=False,nrpn=False,art='html',build={'root':'..','sources':['src/plugin.cpp']})
(root/'vst/vst.json').write_text(json.dumps(cfg,indent=2))
base='''style=dark
art_css=art/monochrome.css
theme_bg=d1d3d4
theme_panel=d1d3d4
theme_ink=080808
theme_ink_dim=ffffff
theme_accent=ffffff
theme_accent_hi=ffffff
theme_knob_face=ffffff
theme_knob_dot=ffffff
theme_seg_active=ffffff
theme_seg_inactive=080808
theme_seg_active_tx=080808
knob_look=cap
label_scale=1.1
'''
lines=[base,'[tab Tape]','art file=art/tape.svg'];labels=[]
for key,label,x,y in [('wow','WOW',225,300),('volume','VOLUME',640,300),('model','MODEL / LP',1055,300),('flutter','FLUTTER',225,524),('saturate','SATURATE / GEN',640,524),('failure','FAILURE / HP',1055,524)]:
 lines.append(f'knob cx={x} cy={y} r=58 ns=0 vs=27 ink_dim=080808 key={key} label="{label}"');labels.append((x,y-70,label))
lines.append('slider_h cx=380 cy=646 w=390 h=56 ns=0 vs=23 key=mix label="MIX"');labels.append((380,607,'MIX'))
lines.append('enum_h cx=900 cy=665 key=noise label="" sw=130 sh=48');labels.append((900,630,'NOISE'))
lines+=['qlinks "Tape" = wow,volume,model,flutter,saturate,failure,mix,noise'];artwork('tape',labels)
for tab,keys in [('Character',[('hiss','HISS LEVEL'),('mechanical','MECHANICAL'),('crinkle','CRINKLE / POP'),('hum','HUM BYPASS'),('classic','CLASSIC'),('miso','MONO TO STEREO'),('spread','SPREAD')]),('Setup',[('gain','INPUT GAIN'),('drop','DROP BYPASS'),('snag','SNAG BYPASS')])]:
 name=tab.lower();lines += [f'[tab {tab}]',f'art file=art/{name}.svg'];labels=[]
 for i,(key,label) in enumerate(keys):
  x,y=(170+(i%4)*310,310+(i//4)*225) if len(keys)>3 else (250+i*390,420)
  lines.append(f'knob cx={x} cy={y} r=58 ns=0 vs=27 ink_dim=080808 key={key} label="{label}"');labels.append((x,y-70,label))
 lines+=['qlinks "'+tab+'" = '+','.join(k for k,l in keys)];artwork(name,labels)
(root/'vst/layout.conf').write_text('\n'.join(lines)+'\n')
