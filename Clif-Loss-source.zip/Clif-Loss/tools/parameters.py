import json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
spec=[('wow', 'Wow', 0.2, None), ('volume', 'Volume', 0.5, None), ('model', 'Model / LP', 0.25, None), ('flutter', 'Flutter', 0.15, None), ('saturate', 'Saturate / Gen', 0.25, None), ('failure', 'Failure / HP', 0.1, None), ('mix', 'Mix', 0.4, None), ('noise', 'Noise', 0, ['None', 'Mild', 'Heavy']), ('classic', 'Classic', 0, ['Off', 'On']), ('miso', 'Mono to Stereo', 0, ['Off', 'On']), ('spread', 'Spread', 0, ['Off', 'On']), ('drop', 'Drop Bypass', 0, ['Off', 'On']), ('snag', 'Snag Bypass', 0, ['Off', 'On']), ('hum', 'Hum Bypass', 0, ['Off', 'On']), ('hiss', 'Hiss Level', 0.5, None), ('mechanical', 'Mechanical Noise', 0.5, None), ('crinkle', 'Crinkle / Pop', 0.5, None), ('gain', 'Input Gain', 0.5, ['Line', 'Instrument', 'High'])]
params=[]
for key,name,default,opts in spec:
 d=dict(key=key,name=name,default=default,min=0,max=1)
 if opts:d=dict(key=key,name=name,default=opts[round(default*(len(opts)-1))],options=opts)
 params.append(d)
(root/'vst/params.json').write_text(json.dumps(params,indent=2)+'\n')
(root/'src/parameters.hpp').write_text('#pragma once\nstatic constexpr int PARAMS='+str(len(spec))+';\nstatic const char* names[]={'+','.join(json.dumps(x[1]) for x in spec)+'};\nstatic constexpr float defaults[]={'+','.join(f'{float(x[2])}f' for x in spec)+'};\nstatic constexpr int steps[]={'+','.join(str(len(x[3]) if x[3] else 0) for x in spec)+'};\n')

with (root/"src/parameters.hpp").open("a") as f:f.write("enum Parameter {"+",".join("P_"+x[0] for x in spec)+"};\n")
