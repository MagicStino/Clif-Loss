"""Export portable VST2 parameter presets; native host import remains unverified."""
from pathlib import Path
import json,struct
r=Path(__file__).resolve().parent.parent
rows=json.loads((r/'presets/factory.json').read_text())
for row in rows:
 values=list(row['values'].values())
 body=struct.pack('>4sIIII28s','FxCk'.encode(),1,0x4d67474c,100,len(values),row['name'].encode()[:27])+struct.pack('>'+str(len(values))+'f',*values)
 (r/'presets'/(row['name']+'.fxp')).write_bytes(b'CcnK'+struct.pack('>I',len(body))+body)
print('Exported',len(rows),'VST2 parameter presets')
