from pathlib import Path
import struct,json,xml.etree.ElementTree as ET
from xpl import xpl,b64dec
r=Path(__file__).resolve().parent.parent
rows=json.loads((r/'presets/factory.json').read_text())
folder=r/'vst/build/skin/MagicStino - VST - Clif Loss/Presets'
folder.mkdir(parents=True,exist_ok=True)
check=r/'build/preset-chunks';check.mkdir(parents=True,exist_ok=True)
for i,row in enumerate(rows):
 values=list(row['values'].values());name=row['name'].encode()[:23]
 chunk=struct.pack('<4I'+str(len(values))+'f24s',0x474c5354,3,len(values),i,*values,name)
 text=xpl('Clif Loss','MagicStino','%payload-path%/MagicStino - VST - Clif Loss/genloss.so',0x4d67474c,100,chunk,preset=row['name'],effect=True,date='2026-10-28-00-00')
 path=folder/(f'{i:04d}-'+row['name']+'.xpl');path.write_text(text)
 native=r/'presets/native';native.mkdir(exist_ok=True);(native/path.name).write_text(text)
 root=ET.fromstring(text);blob=b64dec(root.findtext('state'));n=struct.unpack('>I',blob[156:160])[0]
 assert blob[:4]==b'CcnK' and blob[8:12]==b'FBCh' and blob[160:]==chunk and n==len(chunk)
 assert root.find('PLUGIN').get('isInstrument')=='0'
 assert row['values']['mix']==.4
 (check/f'{i}.chunk').write_bytes(blob[160:])
print('Exported and decoded',len(rows),'native effect XPL presets with Mix=40%')
