"""Factory settings; keep trigger released so loading a preset never stops audio."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent.parent
params=json.loads((r/'vst/params.json').read_text())
keys=[p['key'] for p in params]
def value(p):return p['options'].index(p['default'])/(len(p['options'])-1) if 'options' in p else p['default']
base=[value(p) for p in params]
spec=[
 ('Clean Start',dict(wow=0,flutter=0,saturate=0,failure=0,model=0), 'Low wear starting point; no added noise.'),
 ('Soft Focus',dict(wow=.08,flutter=.05,saturate=.15,failure=0,model=.08), 'Subtle motion and gentle saturation for a bus or keys.'),
 ('Warm VHS',dict(wow=.18,flutter=.10,saturate=.35,failure=.03,model=.32), 'Rounded video-tape colour with modest movement.'),
 ('Worn Cassette',dict(wow=.3,flutter=.22,saturate=.28,failure=.12,model=.56,noise=.5,hiss=.22), 'More obvious movement, light noise and occasional wear.'),
 ('Rhodes Drive',dict(wow=.06,flutter=.025,saturate=.72,failure=0,model=.16,volume=.40,noise=0,gain=.5), 'Driven electric piano: strong saturation, slight motion, reduced output and no added noise.'),
 ('Noisy Rhodes',dict(wow=.16,flutter=.10,saturate=.6,failure=.06,model=.24,volume=.4,noise=.5,hiss=.65,mechanical=.45,crinkle=.32,gain=.5), 'Electric piano drive with audible hiss, light crackle and uneven tape movement.'),
 ('Wide Memories',dict(wow=.22,flutter=.16,saturate=.2,failure=.04,model=.24,spread=1), 'Stereo motion for sustained material; use on a stereo insert.'),
 ('Cliff Edge',dict(wow=.58,flutter=.42,saturate=.45,failure=.65,model=.72,noise=.5,hiss=.15,crinkle=.7), 'Unstable playback and pronounced failures for transitions.'),
 ('Dusty Loop',dict(wow=.12,flutter=.09,saturate=.32,failure=.08,model=.48,noise=.5,hiss=.3,crinkle=.25,volume=.43), 'Dusty colour for drum loops, with light hiss and modest instability.'),
 ('Classic Haze',dict(classic=1,model=.65,failure=.15,saturate=.35,wow=.2,flutter=.12), 'Classic engine with its LP/HP and generation controls.')]
rows=[]
for name,changes,desc in spec:
 vals=base.copy()
 for key,v in changes.items():vals[keys.index(key)]=v
 rows.append(dict(name=name,description=desc,values=dict(zip(keys,vals))))
(r/'presets').mkdir(exist_ok=True)
(r/'presets/factory.json').write_text(json.dumps(rows,indent=2)+'\n')
(r/'src/presets.hpp').write_text('#pragma once\nstatic constexpr int PROGRAMS='+str(len(rows))+';\nstatic const char* presetNames[]={'+','.join(json.dumps(p['name']) for p in rows)+'};\nstatic constexpr float presetValues[PROGRAMS][PARAMS]={\n'+',\n'.join('{'+','.join(f'{v:.9f}f' for v in p['values'].values())+'}' for p in rows)+'\n};\n')
(r/'docs/PRESETS.md').write_text('# Factory presets\n\n'+''.join('## '+p['name']+'\n\n'+p['description']+'\n\n' for p in rows)+'These are starting points designed from the controls, not matched recordings of a physical pedal. Adjust Volume for your source. Host insert bypass remains separate. Tape Stop and pedal Aux controls are intentionally omitted.\n')
