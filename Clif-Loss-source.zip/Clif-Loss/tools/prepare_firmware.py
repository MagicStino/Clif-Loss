from pathlib import Path
import json,struct,sys,hashlib
root=Path(__file__).resolve().parent.parent
if len(sys.argv)!=2: raise SystemExit('Usage: python3 tools/prepare_firmware.py /path/to/genLoss1.1.0.bin')
b=bytearray(Path(sys.argv[1]).read_bytes())
if hashlib.sha256(b).hexdigest()!='f9bfb4bfb28c551c1390a6ff1fc5c26873f5e3381ace65b7b363bd22e86cba67': raise SystemExit('Wrong firmware: requires exact Generation Loss MKII 1.1.0 image')
# Thumb-2 B.W immediate, ARM ARM encoding T4.
def branch(src,dst):
 x=(dst-src-4)&0x1ffffff
 s=(x>>24)&1;i1=(x>>23)&1;i2=(x>>22)&1;j1=1^(i1^s);j2=1^(i2^s)
 return struct.pack('<HH',0xf000|(s<<10)|((x>>12)&0x3ff),0x9000|(j1<<13)|(j2<<11)|((x>>1)&0x7ff))
# VMOV scalar register T1, single precision. IT condition does not alter FP state.
def vmov(dst,src):return struct.pack('<HH',0xeeb0|((dst&1)<<6),((dst>>1)<<12)|0xa40|((src&1)<<5)|(src>>1))
patches=[]
for off,cond,dst,src in [(0x100fe,0,15,0),(0x10156,0xb,0,15),(0x10232,0xb,15,14)]:
 tramp=len(b)
 b.extend(struct.pack('<H',0xbf08|(cond<<4))+vmov(dst,src)+branch(tramp+6,off+4))
 b[off:off+4]=branch(off,tramp)
 patches.append({'offset':hex(off),'trampoline':hex(tramp),'reason':'VSEL replacement; conditional register move preserving flags'})
# Hardware GPIO and short hardware-only software wait are intercepted outside DSP.
for off in [0x9e20,0x954]: b[off:off+2]=bytes.fromhex('7047')
(root/'build').mkdir(exist_ok=True)
(root/'build/engine.bin').write_bytes(b)
relocs=json.loads((root/'tools/relocations.json').read_text())
header='#pragma once\n#include <cstdint>\nstatic const uint8_t engine_blob[]={\n'+',\n'.join(','.join(str(v) for v in b[i:i+24]) for i in range(0,len(b),24))+'\n};\nstatic const uint32_t engine_relocs[]={'+','.join(str(v) for v in relocs)+'};\n'
(root/'src/engine_blob.hpp').write_text(header)
print('Prepared local firmware header:',len(b),'bytes;',len(relocs),'relocations')
