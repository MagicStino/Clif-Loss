from pathlib import Path
import sys,json,re
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parent.parent
skin=root/'vst/build/skin/MagicStino - VST - Clif Loss/Plugin Skins'
params=json.loads((root/'vst/params.json').read_text())
factory=json.loads((root/'presets/factory.json').read_text())[0]['values']
for p in params:
 v=factory[p['key']];p['default']=p['options'][round(v*(len(p['options'])-1))] if 'options' in p else v
def norm(p):return p['options'].index(p['default'])/(len(p['options'])-1) if 'options'in p else p['default']
def label(p):
 if p["key"]=="mix":return f"{p["default"]*100:.0f}% wet"
 return p['default'] if 'options'in p else f"{p['default']*100:.1f}"
t=json.loads((skin/'TUI.json').read_text())['pageData'];defs={x['key']:x['value'] for x in t['componentDefinitions']['localComponentDefinitions']}
bounds=lambda c:[round(float(n))for n in c['bounds']['bounds'].split()]
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
for idx,tab in enumerate(t['tabs']):
 im=Image.new('RGB',(1280,628));d=ImageDraw.Draw(im)
 for c in defs[tab['componentName']]['componentsData']:
  cd=c['componentData'];x,y,w,h=bounds(c)
  if cd['type']=='Image':
   a=Image.open(skin/cd['data']['image']).convert('RGBA');im.paste(a,(x,y),a);continue
  maps=c.get('handle remapping',{}).get('map',[]);m=next((re.search(r'Parameter (\d+)',z['value']) for z in maps if re.search(r'Parameter (\d+)',z['value'])),None)
  p=params[int(m[1])] if m else params[0]
  for s in defs[cd['type']]['componentsData']:
   sd=s['componentData'];sx,sy,sw,sh=bounds(s);data=sd['data'];kind=sd['type']
   if kind=='Image':a=Image.open(skin/data['image']).convert('RGBA');im.paste(a,(x+sx,y+sy),a)
   elif kind=='Knob':
    a=Image.open(skin/data['filmStrip']).convert('RGBA');fh=sh;count=a.height//fh;k=round(norm(p)*(count-1));a=a.crop((0,k*fh,a.width,(k+1)*fh));im.paste(a,(x+sx,y+sy),a)
   elif kind=='Button':
    count=data.get('numButtonsInGroup',1);selected=(norm(p)>=.5) if count==1 else round(norm(p)*(count-1))==data.get('buttonId',0)
    file=data.get('onImage' if selected else 'offImage');
    if file:a=Image.open(skin/file).convert('RGBA');im.paste(a,(x+sx,y+sy),a)
   elif kind=='Label':
    txt=cd.get('name','') if data.get('type')=='Name' else label(p)
    ts=data['textStyle'];f=ImageFont.truetype(font,int(ts['font']['height']));rgb='#'+ts['colour'][-6:];box=d.textbbox((0,0),txt,font=f);tw,th=box[2]-box[0],box[3]-box[1]
    d.text((x+sx+(sw-tw)/2-box[0],y+sy+(sh-th)/2-box[1]),txt,font=f,fill=rgb)
 im.save(root/f'docs/panel-{idx}.png')
print('Rendered three native-skin layout previews at default control values.')
