# Controls on Force / MPC

Use an audio insert slot. Main sound controls stay on Tape; Character holds the detail controls. The screen, Q-Links, host automation and saved state use the same parameters.

| Page | Mapped controls, in layout order |
|---|---|
| Tape | Wow, Volume, Model/LP, Flutter, Saturate/Gen, Failure/HP, Mix, Noise |
| Character | Hiss, Mechanical Noise, Crinkle/Pop, Hum Bypass, Classic, Mono to Stereo, Spread |

The physical knob order needs confirmation on a device. The generated skin uses the existing toolkit's physical Q-Link map. All 15 visible controls are automatable. Options keep continuous host readback for Q-Link delta accumulation and are quantized inside the processor.

Start with Clean Start or Soft Focus. Choose Rhodes Drive for saturation with little motion, or Noisy Rhodes for more hiss and texture. Adjust Volume to the source. Mix is a linear dry/wet blend starting at 40% wet: 0% is original audio and 100% is processed. The old pedal Dry and Dry Type switches are intentionally replaced by this host-native mix. Use the host insert bypass to compare processed and unprocessed sound.

Tape Stop and Aux are intentionally excluded. There is no STOP/PLAY/RECORD control or capacitive-touch trigger. The early Aux research is retained only in the technical findings log.

Hardware verification still needed: insert discovery, factory-program availability, physical Q-Link order, automation Write/Read, project save/reload, bypass latency, CPU and audio underruns. Native XPL presets load on the user’s Force. The preset display fix still needs confirmation on its screen.
